#!/usr/bin/env python3
# _*_coding:utf-8_*_
# by liuyang

name = 'liuyang'
def sayhi(name):
    print("hello %s" % name)