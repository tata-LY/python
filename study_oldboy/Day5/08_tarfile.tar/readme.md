01. module_test 模块简单例子
02. package包简单例子
03. time/datatime模块
04. random模块
05. os模块
06. sys模块
07. shutil模块
08. zipfile、tarfile模块